This directory contains sample scripts to:
1) use PeaZip from command line scripts
2) integrate PeaZip with host system

bat folder contains Windows .bat scripts
freedesktop_integration folder contains .desktop files for Linux and BSD desktop environments, plus some desktop specific scripts (e.g. KDE service menus)
macOS service menus folder contains Automator scripts to integrate PeaZip in macOS context menu
sh folder contains .sh scripts for Linux and generic *x like environemnts
Windows folder contains SendTo menu links and .reg scripts for integration in Windows 11 mini context menu