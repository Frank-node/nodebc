MAIN-EMBEDDED
Embedded themes does not contain .theme file nor graphic, that is embedded in PeaZip for maximum startup performances.
Main theme provides icons meant for a "neutral" look and feel, in order to be visually familiar to users of different operating systems such as macOS, Windows, and various Linux desktop environments.